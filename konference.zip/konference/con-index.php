<?php 
//// vstupni bod webove aplikace
/// zde jsou zapsány všshnz dostupne stranky a i potřebná práva k jejich načtení
$dostupne = array(
              "uvod" => array("controller" => "controler/con-konference.class.php",               "object" => "ConUvod",                 "prava" => 100),
              "login" => array("controller" => "controler/con-login.class.php",               "object" => "conlogin",                "prava" => 100),
              "kontakty" => array("controller" => "controler/con-kontakty.class.php",            "object" => "conKontakty",             "prava" => 100),
              "registrace" => array("controller" => "controler/con-registrace.class.php",          "object" => "conRegistrace",           "prava" => 100),
              "nastaveni" => array("controller" => "controler/con-nastaveni-uzivatele.class.php", "object" => "conNastaveniUzivatele",   "prava" => 4),
              "prispevkyAdmin" => array("controller" => "controler/con-prispevky-admin.class.php",         "object" => "conPrispevkyAdmin",           "prava" => 3),

              "priRecAdmin" => array("controller" => "controler/con-prirazenirecenzi-admin.class.php",     "object" => "conPrirazeniRecenziAdmin",       "prava" => 2),
              "uzivateleAdmin" => array("controller" => "controler/con-uzivatele-admin.class.php",     "object" => "conUzivateleAdmin",       "prava" => 1)
);

// mam pozadavek na zobrazeni webu a pozadovana stranka je mezi dostupnymi strankami
if(isset($_GET['web']) && in_array($_GET['web'], array_keys($dostupne))){




    $pristup = false;
    // ziskam popis aktualne zvolene stranky
    $aktualni = $dostupne[$_GET['web']];
    require($aktualni["controller"]);
    $contr = new $aktualni['object'];



//je hledana stranka přístupna bez přihlašení?
   if($aktualni["prava"]  > 99){
       $pristup = true;
//je  uzivatel přihlašený?
   }elseif(isset($_SESSION["user"]["ROLE"])){

       if($aktualni["prava"] == 4){
           $pristup = true;
       }elseif($_SESSION["user"]["ROLE"] == $aktualni["prava"] || $_SESSION["user"]["ROLE"] == 1){
               $pristup = true;}else {$hlaseniTit = "Vaš práva vás neopravňují pro vstup na tuto stránku.<button type='button' class=''><a href='con-index.php?web=uvod'>zpet do obchodu</a></button> ";}
/// má uživatel dominantnější prava  nebo rovna se stránkou?
   }else{$hlaseniTit = "Pro vstup na tuto stranku musiš být přihlašen<button type='button' class=''><a href='con-index.php?web=uvod'>zpet do obchodu</a></button> ";}

    // prilinkuji soubor zvoleneho webu a vytvorim jeho objekt

if($pristup){
    // volam funkci kontroleru a vypisu jeho vystup
    echo $contr->getResult();
}

}  else {$hlaseniTit = "stránka není dostupná";}
    // vstup neni spravny - pouze vypisu mini HTML
if( isset($hlaseniTit)){
    echo "<html><head><meta charset='utf-8'></head><body>$hlaseniTit</body></html>";
}

?>