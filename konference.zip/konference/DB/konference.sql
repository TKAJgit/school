-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Počítač: 127.0.0.1
-- Vytvořeno: Úte 09. led 2018, 14:00
-- Verze serveru: 10.1.28-MariaDB
-- Verze PHP: 5.6.32

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `konference`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `prispevek`
--

CREATE TABLE `prispevek` (
  `id_PRISPEVEK` int(11) NOT NULL,
  `nazev` varchar(45) DEFAULT NULL,
  `platnost` int(11) DEFAULT NULL,
  `pdf` varchar(45) DEFAULT NULL,
  `abstrakt` varchar(45) DEFAULT NULL,
  `id_AUTOR` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vypisuji data pro tabulku `prispevek`
--

INSERT INTO `prispevek` (`id_PRISPEVEK`, `nazev`, `platnost`, `pdf`, `abstrakt`, `id_AUTOR`) VALUES
(4, 'l', 0, 'f', 'f', 3),
(5, 'jmeno', 0, 'j', 'j', 3),
(10, 'f', 0, 'pdf', 'abstrakt', 1),
(11, 'nazev', 0, 'pdf', 'abstrakt', 1),
(14, 'Ahoj', 0, 'pdf', 'abstrakt', 1),
(38, 'Ahoj', 0, 'obr5.png', 'abstrakt', 1),
(39, 'Atribut', 0, 'obr2.png', 'abstrakt', 2),
(40, 'Atribut2', 0, 'out3.jpg', 'abstrakt', 2),
(41, 'Atribut2', 0, 'Clipboard01.jpg', 'abstrakt', 1);

-- --------------------------------------------------------

--
-- Struktura tabulky `recenze`
--

CREATE TABLE `recenze` (
  `gramatika` int(11) DEFAULT NULL,
  `srozumitelnost` int(11) DEFAULT NULL,
  `narocnost` int(11) DEFAULT NULL,
  `id_PRISPEVEK` int(11) NOT NULL,
  `id_RECENZENT` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vypisuji data pro tabulku `recenze`
--

INSERT INTO `recenze` (`gramatika`, `srozumitelnost`, `narocnost`, `id_PRISPEVEK`, `id_RECENZENT`) VALUES
(5, 1, 5, 14, 3),
(NULL, NULL, NULL, 11, 3),
(2, 4, 5, 14, 2),
(2, 4, 5, 14, 2);

-- --------------------------------------------------------

--
-- Struktura tabulky `role`
--

CREATE TABLE `role` (
  `id_ROLE` int(11) NOT NULL,
  `nazev` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vypisuji data pro tabulku `role`
--

INSERT INTO `role` (`id_ROLE`, `nazev`) VALUES
(1, 'Admin'),
(2, 'Redaktor'),
(3, 'Autor'),
(4, 'blokovan');

-- --------------------------------------------------------

--
-- Struktura tabulky `uzivatel`
--

CREATE TABLE `uzivatel` (
  `id_UZIVATEL` int(11) NOT NULL,
  `ROLE` int(11) NOT NULL,
  `login` varchar(45) NOT NULL,
  `jmeno` varchar(45) NOT NULL,
  `prijmeni` varchar(45) NOT NULL,
  `heslo` varchar(45) NOT NULL,
  `mail` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Vypisuji data pro tabulku `uzivatel`
--

INSERT INTO `uzivatel` (`id_UZIVATEL`, `ROLE`, `login`, `jmeno`, `prijmeni`, `heslo`, `mail`) VALUES
(1, 1, 'Pav', 'Pav', 'Pav', 'Pav', 'Pav@gmail.com'),
(2, 2, 'a', 'a', 'a', 'a', 'a@gmail.com'),
(3, 3, 'c', 'c', 'c', 'c', 'sdsde@gmao.com');

--
-- Klíče pro exportované tabulky
--

--
-- Klíče pro tabulku `prispevek`
--
ALTER TABLE `prispevek`
  ADD PRIMARY KEY (`id_PRISPEVEK`),
  ADD KEY `fk_PRISPEVEK_UZIVATEL1_idx` (`id_AUTOR`);

--
-- Klíče pro tabulku `recenze`
--
ALTER TABLE `recenze`
  ADD KEY `fk_RECENZE_PRISPEVEK1_idx` (`id_PRISPEVEK`),
  ADD KEY `fk_RECENZE_UZIVATEL1_idx` (`id_RECENZENT`);

--
-- Klíče pro tabulku `role`
--
ALTER TABLE `role`
  ADD PRIMARY KEY (`id_ROLE`);

--
-- Klíče pro tabulku `uzivatel`
--
ALTER TABLE `uzivatel`
  ADD PRIMARY KEY (`id_UZIVATEL`),
  ADD KEY `fk_UZIVATEL_PRAVA_UZIVATELU1_idx` (`ROLE`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `prispevek`
--
ALTER TABLE `prispevek`
  MODIFY `id_PRISPEVEK` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT pro tabulku `role`
--
ALTER TABLE `role`
  MODIFY `id_ROLE` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT pro tabulku `uzivatel`
--
ALTER TABLE `uzivatel`
  MODIFY `id_UZIVATEL` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Omezení pro exportované tabulky
--

--
-- Omezení pro tabulku `prispevek`
--
ALTER TABLE `prispevek`
  ADD CONSTRAINT `fk_PRISPEVEK_UZIVATEL1` FOREIGN KEY (`id_AUTOR`) REFERENCES `uzivatel` (`id_UZIVATEL`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Omezení pro tabulku `recenze`
--
ALTER TABLE `recenze`
  ADD CONSTRAINT `fk_RECENZE_PRISPEVEK1` FOREIGN KEY (`id_PRISPEVEK`) REFERENCES `prispevek` (`id_PRISPEVEK`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_RECENZE_UZIVATEL1` FOREIGN KEY (`id_RECENZENT`) REFERENCES `uzivatel` (`id_UZIVATEL`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Omezení pro tabulku `uzivatel`
--
ALTER TABLE `uzivatel`
  ADD CONSTRAINT `fk_UZIVATEL_PRAVA_UZIVATELU1` FOREIGN KEY (`ROLE`) REFERENCES `role` (`id_ROLE`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
