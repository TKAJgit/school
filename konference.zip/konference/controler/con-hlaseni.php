<?php



class conHlaseni
{
    public function __construct()
    { }
    public function speech($text,$typ)
    {
    $upozorneni =" <div class='alert alert-$typ'>
                      <strong>$typ!</strong> $text
                     </div>";
        return $upozorneni;
    }

}

?>