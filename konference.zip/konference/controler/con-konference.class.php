<?php

/**
 * Class ConUvod.
 * Kontroler pro zobrazeni uvodni stranky.
 */
class ConUvod {


    private $sprava;

    /**
     * zajištuje komunikaci s databazí
     * ConUvod constructor.
     */
    public function __construct() {
        require "models/mod-databaze.class.php";
        $this->sprava = new ModDatabaze;
    }

    /**
     *  Vrati obsah stranky
     *  @return string Obsah stranky
     */
    public function getResult(){
        // urcim, ktere promenne budou globalni, tj. vyuzity v sablone
        global $hlaseni, $title, $prispevek, $rozcestnikl,$hodnoceni, $upozorneni;
        // naplnim globalni promenne
        $title = "Konference"; // nadpis
        $fotky= [];
        ///rozcestnik podle prav
        require "con-rozcestnik.php";
        $this->rozcestnik = new conRozcestnik;
        $rozcestnikl = $this->rozcestnik->selectTheCrossroads();

        $prispevek = $this->sprava->allContributionValidity();
        foreach ($prispevek as $pris){
            $hodnoceni[$pris['id_PRISPEVEK']]  = $this->sprava->sumReviewInfo($pris['id_PRISPEVEK']) ;
            $pocet =$this->sprava->coutReviewInfo($pris['id_PRISPEVEK']);
            //$hlaseni = $pocet;
            if($pocet[0]['pocet'] != 0){
                $hodnoceni[$pris['id_PRISPEVEK']][0]['narocnost'] /= $pocet[0]['pocet'];
                $hodnoceni[$pris['id_PRISPEVEK']][0]['srozumitelnost'] /= $pocet[0]['pocet'];
                $hodnoceni[$pris['id_PRISPEVEK']][0]['gramatika'] /= $pocet[0]['pocet'];
            }

            ;
        }

        //adresa k hlaseni.php
        require "con-hlaseni.php";
        $this->hlasen = new conHlaseni;
        if(isset($_POST["Download"])){



            $file = "./soubory/".$_POST['foto'];

            header("Content-Disposition: attachment; filename=" . urlencode($_POST['foto']));
            header("Content-Type: application/octet-stream");
            header("Content-Type: application/download");
            header("Content-Description: File Transfer");
            header("Content-Length: " . filesize($file));
            flush(); // this doesn't really matter.
            $fp = fopen($file, "r");
            while (!feof($fp))
            {
                echo fread($fp, 65536);
                flush(); // this is essential for large downloads
            }

            fclose($fp);

            $hlaseni = $this->hlasen->speech("Soubor stažen.","success");
            header("Refresh:1");
        }


        // odchytim vystup sablony a ulozim ho do promenne $obsah
        ob_start();

            require "view/view-konference.template.php";
        $obsah = ob_get_clean();


        // vracim sablonu naplnenou daty
        return $obsah;
    }


}



?>