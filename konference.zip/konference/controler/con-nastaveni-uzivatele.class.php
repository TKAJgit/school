<?php
class conNastaveniUzivatele
{

    /** @var ModDatabaze $sprava Trida obstaravajici praci s databazi. */
    private $sprava;

    /**
     *  zajištuje komunikaci s databazí
     * conNastaveniUzivatele constructor.
     */
    public function __construct()
    {
        require "models/mod-databaze.class.php";
        $this->sprava = new ModDatabaze;
    }

    /**
     *  Vrati obsah stranky
     * @return string Obsah stranky
     */
    public function getResult()
    {
        // urcim, ktere promenne budou globalni, tj. vyuzity v sablone
        global $title, $users, $hlaseni, $createSelectBox,$rozcestnikl;
        $users = $this->sprava->allUsersInfo(); // ziskani druhy z DB
        $title = "Nastavení";
        $hlaseni = "";

        ///rozcestnik podle prav
        require "con-rozcestnik.php";
        $this->rozcestnik = new conRozcestnik;
        $rozcestnikl = $this->rozcestnik->selectTheCrossroads();


        //adresa k hlaseni.php
        require "con-hlaseni.php";
        $this->hlasen = new conHlaseni;


        // vrací selectbox s právy
        $createSelectBox = $this->createSelectBox($this->sprava->allRights(),$_SESSION["user"]["ROLE"]);
        // zajištuje změnu udajů
        if(isset($_POST['potvrzeni'])){ // mam vstup
            $login = htmlspecialchars($_SESSION["user"]["login"]);
            $heslo_puvodni = htmlspecialchars($_POST["heslo-puvodni"]);

            if($this->sprava->isPasswordCorrect($login, $heslo_puvodni)){ // odpovida aktualni heslo heslu v DB?
                if($_POST["heslo"]==$_POST["heslo2"]){ // odpovidaji si odeslana hesla
                    //print_r($_POST);
                    if($_POST["heslo"]==""){ // pokud neni zadano heslo, tak zustava puvodni

                        $heslo = htmlspecialchars($_SESSION["user"]["heslo"]);// puvodni
                    } else {
                        $heslo = htmlspecialchars($_POST["heslo"]);// nove

                    }
                    $id_UZIVATEL = $_SESSION["user"]["id_UZIVATEL"] + 0;
                    $jmeno = htmlspecialchars($_POST["jmeno"]);
                    $email = htmlspecialchars( $_POST["email"]);
                    $pravo = $_POST["pravo"] + 0 ;

                    $this->sprava->updateUserInfo($id_UZIVATEL, $jmeno, $heslo, $email, $pravo);
                    // mohlo se zmenit heslo, tak radeji znovu prihlasim
                    $this->sprava->userLogin($login ,$heslo);
                    $hlaseni = $this->hlasen->speech("Osobní údaje byly změněny.","success");
                    header("Refresh:1");
                } else {
                    $hlaseni = $this->hlasen->speech("Vámi zadaná hesla nejsou stejná!","warning");

                }
            } else {
                $hlaseni = $this->hlasen->speech("Vámi zadané současné heslo není správné!","danger");
            }
        }
        // odchytim vystup sablony a ulozim ho do promenne $obsah
        ob_start();

        require "view/view-nastaveni-uzivatele.template.php";
        $obsah = ob_get_clean();


        // vracim sablonu naplnenou daty
        return $obsah;
    }

    /**
     *  Vytvori selectbox s pravi uzivatelu.
     *  @param array $rights    Vsechna dostupna prava.
     *  @param integer $selected    Zvolena polozka nebo null.
     *  @return string          Vytvoreny selectbox.
     */
    function createSelectBox($rights,$selected){
        $res = '<select name="pravo">';
        foreach($rights as $r){
            if($selected!=null && $selected==$r['id_ROLE']){ // toto bylo ve stupu
                $res .= "<option value='".$r['id_ROLE']."' selected>$r[nazev]</option>";
            } else { // nemam vstup
                $res .= "<option value='".$r['id_ROLE']."'>$r[nazev]</option>";
            }
        }
        $res .= "</select>";
        return $res;
    }
}
?>