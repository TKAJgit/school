<?php

/**
 * Class ConUvod.
 * Kontroler pro zobrazeni uvodni stranky.
 */
class conPrispevkyAdmin {

    /** @var ModDatabaze $sprava Trida obstaravajici praci s databazi. */
    private $sprava;

    /**
     *  zajištuje komunikaci s databazí
     * confotkyAdmin constructor.
     */
    public function __construct() {
        require "models/mod-databaze.class.php";
        $this->sprava = new ModDatabaze;
    }

    /**
     *  Vrati obsah stranky
     *  @return string Obsah stranky
     */
    public function getResult(){
        // urcim, ktere promenne budou globalni, tj. vyuzity v sablone
        global $title, $hlaseni,$rozcestnikl,$prispevky,$zapsat,$platnost, $upozorneni ;
        // naplnim globalni promenne
        $title = "Příspěvek Admin"; // nadpis
        if(($_SESSION["user"]["ROLE"] + 0) == 1) {
            $prispevky = $this->sprava->allContribution(); // ziskani prispevky z DB
        }else{
            $prispevky = $this->sprava->allContributionByIdUser(); // ziskani prispevky z DB
        }
        $platnost = $this->writeArticleState($prispevky);

        ///rozcestnik podle prav
        require "con-rozcestnik.php";
        $this->rozcestnik = new conRozcestnik;
        $rozcestnikl = $this->rozcestnik->selectTheCrossroads();

        //adresa k hlaseni.php
        require "con-hlaseni.php";
        $this->hlasen = new conHlaseni;
        if(isset($_POST['zapsat'])){ /////////////////////////////ZAPSAT PRISPEVEK
            $targetfolder = "soubory/";
            $targetfolder = $targetfolder . basename( $_FILES['file']['name']) ;
            if(move_uploaded_file($_FILES['file']['tmp_name'], $targetfolder))
            {
               $hlaseni = "The file ". basename( $_FILES['file']['name']). " is uploaded";


                $nazev = htmlspecialchars($_POST['nazev']);
                $pdf = htmlspecialchars($_FILES['file']['name']);
                $abstrakt = htmlspecialchars($_POST['abstrakt']);
                if($this->sprava->addNewContribution($nazev, $pdf, $abstrakt,$_SESSION["user"]["id_UZIVATEL"])){
                    $hlaseni = $this->hlasen->speech("pridán přispšvek :)".basename( $_FILES['file']['name']),"info");

                }else{

                    $hlaseni = $this->hlasen->speech("Nastali komplikace, přispšvek nepřidán :(","warning");
                   }
            }else {
                $hlaseni = $this->hlasen->speech("problém při nahrávání souboru","warning");

            }
            header("Refresh:2");
        }elseif (isset($_POST['upravit'])){//////////////////////UPRAVIT PRISPEVEK
            $nazev = htmlspecialchars($_POST['nazev']);
            $pdf = htmlspecialchars($_POST['pdf']);
            $abstrakt = htmlspecialchars($_POST['abstrakt']);
            $id_prispevek = htmlspecialchars($_POST['id_prispevek']);
            $paltnostt = 0 + $_POST['paltnost'];
            if($this->sprava->updateContributionInfo($nazev, $pdf, $abstrakt,$id_prispevek, $paltnostt)){



                $hlaseni = $this->hlasen->speech("Upraven přispšvek","info");

            }else{$hlaseni ="Nastali komplikace, přispšvek neupraven :(.";

                $hlaseni = $this->hlasen->speech("Nastali komplikace, přispšvek neupraven :(","warning");

            }
           header("Refresh:1");
        }
        /////////////////////////////////reakce na formular konec////////////////////////////////////////
        // odchytim vystup sablony a ulozim ho do promenne $obsah
        ob_start();

        require "view/view-prispevky-admin.template.php";
        $obsah = ob_get_clean();


        // vracim sablonu naplnenou daty
        return $obsah;
    }


    function writeArticleState($prispevky)
    {
        if(($_SESSION["user"]["ROLE"] + 0) == 1){
            foreach ($prispevky as $prispevek) {

                 $platnost[$prispevek['id_PRISPEVEK']] = "<input type='range' id='a' name='paltnost' value='$prispevek[platnost]' min='0' max='2' oninput='x.value=parseInt(a.value);'><output name='x' for='a'>$prispevek[platnost]</output>";
            }
        }else{
            foreach ($prispevky as $prispevek) {
                $platnost[$prispevek['id_PRISPEVEK']] = $prispevek['platnost'];
            }
        }

        return $platnost;
    }





}
?>