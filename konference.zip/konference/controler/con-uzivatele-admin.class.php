<?php
class conUzivateleAdmin
{

    /** @var ModDatabaze $sprava Trida obstaravajici praci s databazi. */
    private $sprava;

    /**
     * zajištuje komunikaci s databazí
     * conUzivateleAdmin constructor.
     */
    public function __construct()
    {
        require "models/mod-databaze.class.php";
        $this->sprava = new ModDatabaze;
    }

    /**
     *  Vrati obsah stranky
     * @return string Obsah stranky
     */
    public function getResult()
    {
        // urcim, ktere promenne budou globalni, tj. vyuzity v sablone
        global $title, $users, $hlaseni, $rozcestnikl,$createSelectBox;
        $users = $this->sprava->allUsersInfo(); // ziskani druhy z DB
        $title = "Uzivatele-Admin";
        $hlaseni = "";
        ///rozcestnik podle prav
        require "con-rozcestnik.php";
        $this->rozcestnik = new conRozcestnik;
        $rozcestnikl = $this->rozcestnik->selectTheCrossroads();

        //adresa k hlaseni.php
        require "con-hlaseni.php";
        $this->hlasen = new conHlaseni;

        $createSelectBox = $this->createSelectBox($this->sprava->allRights(),null);
            // zajištuje reakci na dotazi
        if (isset($_POST["upravit"]) && isset($_POST["user-id"])){

            $pravo = htmlspecialchars($_POST["pravo"]);
            $user_id = $_POST["user-id"] + 0;
            $res = $this->sprava->updateUserRights($user_id, $pravo);
            header("Refresh:2");
            if($res){

                $hlaseni = $this->hlasen->speech("Uživatel s ID:".$user_id." ma změněna prava.","success");
            }   else {

                $hlaseni = $this->hlasen->speech("Uživatele s ID:".$user_id." Nema zmněněná prava.!","warning");

            }
        }elseif (isset($_POST["smazat"])){
            $user_id = $_POST["user-id"] + 0;
            $opravneni = $_SESSION["user"]["ROLE"];
            if($opravneni == 1){
                $res = $this->sprava->deleteUser($user_id);
                if($res){
                    $hlaseni = $this->hlasen->speech("Uživatel s ID:".$user_id." byl smazan.","success");

                }   else {
                    $hlaseni = $this->hlasen->speech("Uživatele s ID:".$user_id."  se nepodařilo smazat.!","warning");


                }
            }else{
                $hlaseni = $this->hlasen->speech("Nemáte opravněni k ptovedení této akce.","danger");
              }
            header("Refresh:2");
        }

        // }

        // odchytim vystup sablony a ulozim ho do promenne $obsah
        ob_start();

        require "view/view-uzivatele-admin.template.php";
        $obsah = ob_get_clean();


        // vracim sablonu naplnenou daty
        return $obsah;
    }

    /**
     *  Vytvori selectbox s pravi uzivatelu.
     *  @param array $rights    Vsechna dostupna prava.
     *  @param integer $selected    Zvolena polozka nebo null.
     *  @return string          Vytvoreny selectbox.
     */
    function createSelectBox($rights,$selected){
        $res = '<select name="pravo">';
        foreach($rights as $r){
            if($selected!=null && $selected==$r['id_ROLE']){ // toto bylo ve stupu
                $res .= "<option value='".$r['id_ROLE']."' selected>$r[nazev]</option>";
            } else { // nemam vstup
                $res .= "<option value='".$r['id_ROLE']."'>$r[nazev]</option>";
            }
        }
        $res .= "</select>";
        return $res;
    }


}
?>