
<?php
class conRegistrace
{

    /** @var ModDatabaze $sprava Trida obstaravajici praci s databazi. */
    private $sprava;

    /**
     *  zajištuje komunikaci s databazí
     * conRegistrace constructor.
     */
    public function __construct()
    {
        require "models/mod-databaze.class.php";
        $this->sprava = new ModDatabaze;
    }

    /**
     *  Vrati obsah stranky
     * @return string Obsah stranky
     */
    public function getResult()
    {
        // urcim, ktere promenne budou globalni, tj. vyuzity v sablone
        global $title, $hlaseni,$createSelectBox, $rozcestnikl;

        $title = "Registrace";
        $hlaseni = "";



        ///rozcestnik podle prav
        require "con-rozcestnik.php";
        $this->rozcestnik = new conRozcestnik;
        $rozcestnikl = $this->rozcestnik->selectTheCrossroads();

        //adresa k hlaseni.php
        require "con-hlaseni.php";
        $this->hlasen = new conHlaseni;

        if(isset($_POST['potvrzeni'])){ // nova registrace
            $heslo = htmlspecialchars($_POST['heslo']); $heslo2 = htmlspecialchars($_POST['heslo2']);
            if($heslo==$heslo2 ){
                $login = htmlspecialchars($_POST["login"]);
                if($this->sprava->allUserInfo($login)!=null){ // tento uzivatel uz existuje

                    $hlaseni = $this->hlasen->speech("Tento login už existuje. Zvolte si prosím jiný.","danger");
                    header("Refresh:1");
                } else {
                    $jmeno = htmlspecialchars($_POST["jmeno"]);
                    $email = htmlspecialchars($_POST["email"]);
                    $this->sprava->addNewUser($jmeno, $login, $heslo, $email, 3);
                    $this->sprava->userLogin($login,$heslo);

                    $hlaseni = $this->hlasen->speech("Nový uživatel webu byl vytvořen a přihlášen!","success");
                    header("Refresh:1");
                }
            } else {

                $hlaseni = $this->hlasen->speech("Hesla nejsou stejná!","warning");
                header("Refresh:1");
            }
        }

        // }

        // odchytim vystup sablony a ulozim ho do promenne $obsah
        ob_start();

        require "view/view-registrace.template.php";
        $obsah = ob_get_clean();


        // vracim sablonu naplnenou daty
        return $obsah;
    }



}
?>