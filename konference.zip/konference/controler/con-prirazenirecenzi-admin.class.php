<?php
class conPrirazeniRecenziAdmin {

    /** @var ModDatabaze $sprava Trida obstaravajici praci s databazi. */
    private $sprava;

    /**
     *  zajištuje komunikaci s databazí
     * conGalerieAdmin constructor.
     */
    public function __construct() {
        require "models/mod-databaze.class.php";
        $this->sprava = new ModDatabaze;
    }

    /**
     *  Vrati obsah stranky
     *  @return string Obsah stranky
     */
    public function getResult(){
        // urcim, ktere promenne budou globalni, tj. vyuzity v sablone
        global $title, $recenze,$hlaseni,$rozcestnikl,$zapsatRecenze,  $recenzenti,$prispevky;
        $recenze = $this->sprava->allReviewInfo();  // ziskani prispevky z DB
        $title ="Přiřazení recenzentů";
        $hlaseni = "";
        $recenzenti = $this->sprava->allReviewerInfo();
        $prispevky = $this->sprava->allContribution();

        $recenzenti = $this->createSelectBoxRecenzent($recenzenti,"");
        $prispevky = $this->createSelectBoxPrispevky($prispevky,"");

        ///rozcestnik podle prav
        require "con-rozcestnik.php";
        $this->rozcestnik = new conRozcestnik;
        $rozcestnikl = $this->rozcestnik->selectTheCrossroads();

        if(($_SESSION["user"]["ROLE"] + 0) == 1){
            $zapsatRecenze  = $this->writeReview($recenzenti,$prispevky);
            $recenze = $this->sprava->allReviewInfo();  // ziskani prispevky z DB
            //$douwload = $this->sprava->allDowloadInfoById($_SESSION["user"]["id_UZIVATEL"]);  // ziskani prispevky z DB
        }else{
           $zapsatRecenze  ="";

          $recenze = $this->sprava->allReviewInfoById($_SESSION["user"]["id_UZIVATEL"]);  // ziskani prispevky z DB
         // $douwload = $this->sprava->allDowloadInfoById($_SESSION["user"]["id_UZIVATEL"]);  // ziskani prispevky z DB
        }


        //adresa k hlaseni.php
        require "con-hlaseni.php";
        $this->hlasen = new conHlaseni;


        if(isset($_POST['recenze'])){ /////////////////////////////ZAPSAT PRISPEVEK
            ///
            $gramatika = htmlspecialchars($_POST['gramatika']);
            $srozumitelnost = htmlspecialchars($_POST['srozumitelnost']);
            $narocnost = htmlspecialchars($_POST['narocnost']);
            $id_RECENZENT = $_POST['recenzent'] + 0;
            $id_PRISPEVEK = $_POST['prispevek'] + 0;

            $prisevek = $this->sprava->ContributionByIdContribution($id_PRISPEVEK);

            if($prisevek[0]['platnost'] == 0){
                if($this->sprava->updateReview($gramatika, $srozumitelnost,$narocnost,$id_RECENZENT,$id_PRISPEVEK)){

                    $hlaseni = $this->hlasen->speech("hodnocení přidáno, děkujeme :)","success");
                }else{$hlaseni = $this->hlasen->speech("Nastali komplikace, hodnocení nebylo přidáno.","warning");}
            }else{
                $hlaseni = $this->hlasen->speech("Recenzovaný přispěvek není v stavu k recemzování, buď byl přijat a nebo byl zamítnut. :-","warning");
            }
           header("Refresh:2");

        }elseif (isset($_POST['zapsat'])){//////////////////////UPRAVIT PRISPEVEK

            $id_RECENZENT = $_POST['recenzent'] + 0;
            $id_PRISPEVEK = $_POST['prispevek'] + 0;
            if($this->sprava->existReview($id_RECENZENT,$id_PRISPEVEK)){

                $hlaseni = $this->hlasen->speech("Recenze jiz je zadána zadejte ji někomu jinému   :-/","warning");
            }else{
                if($this->sprava->addNewReview($id_RECENZENT,$id_PRISPEVEK)){
                    $hlaseni = $this->hlasen->speech("Nová recenze :)","success");
                }else{
                    $hlaseni = $this->hlasen->speech("Nastali komplikace :(.","warning");
                }

            }
            header("Refresh:2");
        }



        // odchytim vystup sablony a ulozim ho do promenne $obsah
        ob_start();

        require "view/view-prirazenirecenzi-admin.template.php";
        $obsah = ob_get_clean();


        // vracim sablonu naplnenou daty
        return $obsah;
    }



    function writeReview($recenzenti,$prispevky){
         $zapsat = "<form action='' method='POST' >
                         <td>$recenzenti</td>
                         <td>$prispevky</td>
                  
                         <td>..gramatika..</td> 
                         <td>..srozumitelnost..</td> 
                         <td>..narocnost..</td> 
                         <td>
                            <input type='submit'  class='btn btn-info' name='zapsat' value='zapsat'>                             
                         </td>
                    
                      </form>";

        return $zapsat;
    }

    /**
     *  Vytvori selectbox s jmeny uzivatelu.
     *  @param array $rights    Vsechna dostupna prava.
     *  @param integer $selected    Zvolena polozka nebo null.
     *  @return string          Vytvoreny selectbox.
     */
    function createSelectBoxPrispevky($rights,$selected){
        $res = '<select name="prispevek">';
        foreach($rights as $r){
            if($selected!=null && $selected==$r['id_PRISPEVEK']){ // toto bylo ve stupu
                $res .= "<option value='".$r['id_PRISPEVEK']."' selected>$r[nazev]</option>";
            } else { // nemam vstup
                $res .= "<option value='".$r['id_PRISPEVEK']."'>$r[nazev]</option>";
            }
        }
        $res .= "</select>";
        return $res;
    }

    /**
     *  Vytvori selectbox s jmeny uzivatelu.
     *  @param array $rights    Vsechna dostupna prava.
     *  @param integer $selected    Zvolena polozka nebo null.
     *  @return string          Vytvoreny selectbox.
     */
    function createSelectBoxRecenzent($rights,$selected){
        $res = '<select name="recenzent">';
        foreach($rights as $r){
            if($selected!=null && $selected==$r['id_UZIVATEL']){ // toto bylo ve stupu
                $res .= "<option value='".$r['id_UZIVATEL']."' selected>$r[jmeno]</option>";
            } else { // nemam vstup
                $res .= "<option value='".$r['id_UZIVATEL']."'>$r[jmeno]</option>";
            }
        }
        $res .= "</select>";
        return $res;
    }

}
?>