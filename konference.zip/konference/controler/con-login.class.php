<?php
class conLogin
{

    /** @var ModDatabaze $sprava Trida obstaravajici praci s databazi. */
    private $sprava;
    private $rozcestnik;

    /**
     * conLogin constructor.
     */
    public function __construct()
    {
        require "models/mod-databaze.class.php";
        $this->sprava = new ModDatabaze;
    }

    /**
     *  Vrati obsah stranky
     * @return string Obsah stranky
     */
    public function getResult()
    {
        // urcim, ktere promenne budou globalni, tj. vyuzity v sablone
        global $title, $druhy, $hlaseni,$logInOutView,  $rozcestnikl;

        $title = "login";


        ///rozcestnik podle prav
        require "con-rozcestnik.php";
        $this->rozcestnik = new conRozcestnik;
        $rozcestnikl = $this->rozcestnik->selectTheCrossroads();

        //adresa k hlaseni.php
        require "con-hlaseni.php";
        $this->hlasen = new conHlaseni;

        $logInOutView = $this->logInOutView(); //zobrazeni podletoho zda je uživatel přihlašen či nikoli
        //pokud se chce uživatel odhlásit tak se odhlásí zde
        if(isset($_REQUEST["action"]) && $_REQUEST["action"]=="logout"){
            $action = htmlspecialchars($_REQUEST["action"]);
            if($action=="logout"){
                $this->sprava->userLogout();
                header("Refresh:0");
            }
         }
        // prihlaseni uzivatele
        if(isset($_REQUEST["action"])){

            $action = htmlspecialchars($_REQUEST["action"]);
            if($action =="login"){
                $hlaseni = "<b>d!<b>";
                $login = htmlspecialchars($_REQUEST["login"]);
                $heslo = htmlspecialchars($_REQUEST["heslo"]);
                $res =  $this->sprava->userLogin($login,$heslo);
                header("Refresh:0");

                if(!$res){

                    $hlaseni = $this->hlasen->speech("Přihlášení se nezdařilo!","danger");
                }
            }
        }

        // }

        // odchytim vystup sablony a ulozim ho do promenne $obsah
        ob_start();

        require "view/view-login.template.php";
        $obsah = ob_get_clean();


        // vracim sablonu naplnenou daty
        return $obsah;
    }

    /**
     * funkce zajičtuje zobrazení přihlášeného a nepřihlášeného uživatele
     * @return string
     */
    public function logInOutView(){
       if(! isset($_SESSION["user"])){
           $logInOutView="
             <b>Přihlášení uživatele</b>
        <form action='' method='POST'>
            <table frame='hsides' class='table table-hover'>
                <tr><td>Login:</td><td><input type='text' name='login'></td></tr>
                <tr><td>Heslo:</td><td><input type='password' name='heslo'></td></tr>
            </table>
            <input type='hidden' name='action' value='login'>
            <input type='submit' class='btn btn-primary' name='potvrzeni' value='Přihlásit'>
        </form>" ;
       }else{
           $logInOutView="<b>Přihlášený uživatel</b><br>
                           Jméno: ".$_SESSION['user']['jmeno']."<br>
                            Login: ".$_SESSION['user']['login']."<br>
                            E-mail: ".$_SESSION['user']['mail']."<br>
                            Právo: ".$_SESSION['user']['nazev']."<br>
    <br>

    <b>Odhlášení uživatele:</b>
    <form action='' method='POST'>
        <input type='hidden' name='action' value='logout'>
        <input type='submit' class='btn btn-danger' name='potvrzeni' value='Odhlásit'>
    </form>
       " ;}
        return $logInOutView;
    }

    
}
?>