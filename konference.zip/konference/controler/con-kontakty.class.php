<?php
class conKontakty
{

    /** @var ModDatabaze $sprava Trida obstaravajici praci s databazi. */
    private $sprava;

    /**
     *  zajištuje komunikaci s databazí
     * conKontakty constructor.
     */
    public function __construct()
    {
        require "models/mod-databaze.class.php";
        $this->sprava = new ModDatabaze;
    }

    /**
     *  Vrati obsah stranky
     * @return string Obsah stranky
     */
    public function getResult()
    {
        // urcim, ktere promenne budou globalni, tj. vyuzity v sablone
        global $title,$hlaseni, $rozcestnikl;

        $title = "Kontakty";
        $hlaseni = "";
        ///rozcestnik podle prav
        require "con-rozcestnik.php";
        $this->rozcestnik = new conRozcestnik;
        $rozcestnikl = $this->rozcestnik->selectTheCrossroads();




        // odchytim vystup sablony a ulozim ho do promenne $obsah
        ob_start();

        require "view/view-kontekty.template.php";
        $obsah = ob_get_clean();


        // vracim sablonu naplnenou daty
        return $obsah;
    }
}
    ?>