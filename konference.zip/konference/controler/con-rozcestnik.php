<?php



class conRozcestnik
{
    public function __construct()
    { }
    public function selectTheCrossroads()
    {


        if (!isset($_SESSION["user"])) {
            return "view-rozcestnik.php";
        } else{
            $id_prava= $_SESSION["user"]["ROLE"] + 0;
            if ( $id_prava == 1) {
            return "view-rozcestnik-admin.php";

            }elseif( $id_prava == 2){
                return "view-rozcestnik-redaktor.php";
            }elseif ( $id_prava == 3){
                return "view-rozcestnik-autor.php";
            }
            else{ return "view-rozcestnik.php";}
        }
    }

}

?>