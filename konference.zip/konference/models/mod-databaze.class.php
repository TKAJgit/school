<?php

/**
 * Class ModDatabaze.
 * Obstarava praci s databazi.
 */
class ModDatabaze {

    /** @var PDO $db  */
    private $db;
    
    public function __construct() {
       // global $db_server, $db_name, $db_user, $db_pass;
        $db_server = "127.0.0.1";
        $db_name = "konference";//;"tomiczek_ob"; //tomiczek_obchod_b
        $db_user = "root";
        $db_pass = "";
        // TODO - pri testovani nutne prizpusobit pripojeni k DB !!
       // $this->db = new PDO("mysql:host=$db_server;dbname=$db_name", $db_user, $db_pass);mydb
        $this->db = new PDO("mysql:host=$db_server;dbname=$db_name", $db_user, $db_pass);
       // $this->db = new PDO("mysql:host=localhost;dbname=test", "root","");
        // oprava spatneho kodovani cestiny v DB
        $q = "SET character_set_results = 'utf8', character_set_client = 'utf8', character_set_connection = 'utf8', character_set_database = 'utf8', character_set_server = 'utf8'";
        $this->db->query($q);
        session_start();
    }

    /**
     *  Provede dotaz a buď vrátí jeho výsledek, nebo null a vypíše chybu.
     *  @param string $dotaz    Dotaz.
     *  @return object          Vysledek dotazu.
     */
    private function executeQuery($dotaz){
        $pole = array("dotaz" =>$dotaz);
        $res = $this->db->query($pole['dotaz']);
        if (!$res) {
            $error = $this->db->errorInfo();
            echo $error[2];
            return null;
        } else {
            return $res;
        }
    }

    /**
     *  Prevede vysledny objekt dotazu na pole.
     *  @param object $obj  Objekt s vysledky dotazu.
     *  @return array       Pole s vysledky dotazu.
     */
    private function resultObjectToArray($obj){
        // získat po řádcích
        /*while($row = $vystup->fetch(PDO::FETCH_ASSOC)){
            $pole[] = $row['login'].'<br>';
        }*/
        return $obj->fetchAll(); // všechny řádky do pole
    }
///////////////////////////////prava uzivatelu///////////////////////////
    /**
     *  Vraci prava uzivatelu.
     *  @return array   Dostupna prava uzivatelu.
     */
    public function allRights(){
        $q = "SELECT * FROM role;";
        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        return array_reverse($res); // pole otocim
    }
///////////////////////////////prava uzivatelu konec///////////////////////////



//////////////////////prihlasovani /////////////////////////////
    /**
     *  Overi, zda dany uzivatel ma dane heslo.
     *  @param string $login  Login uzivatele.
     *  @param string $pass     Heslo uzivatele.
     *  @return boolean         Jsou hesla stejna?
     */
    public function isPasswordCorrect($login, $pass){
        $pole = array("login" =>$login,"pass" =>$pass);
        $usr = $this->allUserInfo($pole['login']);
        if($usr==null){ // uzivatel neni v DB
            return false;
        }
        return $usr["heslo"]==$pole['pass']; // je heslo stejne?
    }

    /**
     *  Overi heslo uzivatele a pokud je spravne, tak uzivatele prihlasi.
     *  @param string $login    Login uzivatele.
     *  @param string $pass     Heslo uzivatele.
     *  @return boolean         Podarilo se prihlasit.
     */
    public function userLogin($login, $pass){
        $pole = array("login" =>$login,"pass" =>$pass);
        if(!$this->isPasswordCorrect($pole['login'],$pole['pass'])){// neni heslo spatne?
            return false; // spatne heslo
        }
        // ulozim uzivatele do session
        $_SESSION["user"] = $this->allUserInfo($login);
        return true;
    }

    /**
     *  Odhlasi uzivatele.
     */
    public function userLogout(){
        // odstranim session
        session_unset($_SESSION["user"]);
    }

    /**
     *  Je uzivatel prihlasen?
     */
    public function isUserLoged(){
        return isset($_SESSION["user"]);
    }
//////////////////////prihlasovani konec/////////////////////////////

/////////////////////////uzivatele/////////////////////////////////
    /**
     *  Vraci vsechny informace o uzivateli.
     *  @param string $login    Login uzivatele.
     *  @return array           Pole s informacemi o konkretnim uzivateli nebo null.
     */
    public function allUserInfo($login){
        $pole = array("login" =>$login);
        $q = "SELECT * FROM uzivatel, role
                WHERE uzivatel.login = '$pole[login]'
                  AND  role.id_ROLE = uzivatel.ROLE;";
        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        //print_r($res);
        if($res != null && count($res)>0){
            // vracim pouze prvni radek, ve kterem je uzivatel
            return $res[0];
        } else {
            return null;
        }
    }

    /**
 *  Vraci vsechny informace o vsech uzivatelich.
 *  @return array           Pole s informacemi o konkretnim uzivateli nebo null.
 */
    public function allUsersInfo(){

        $q = "SELECT * FROM uzivatel, role
                WHERE role.id_ROLE = uzivatel.ROLE;";
        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        //print_r($res);
        if($res != null && count($res)>0){
            // vracim vse
            return $res;
        } else {
            return null;
        }
    }

    /**
     *  Vraci vsechny informace o recenzentech (ROLE=2).
     *  @return array           Pole s informacemi o konkretnim uzivateli nebo null.
     */
    public function allReviewerInfo(){

        $q = "SELECT * FROM uzivatel
                WHERE ROLE=2;";
        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        //print_r($res);
        if($res != null && count($res)>0){
            // vracim vse
            return $res;
        } else {
            return null;
        }
    }
    /**
     *  Vytvori v databazi noveho uzivatele.
     *
     *  @return boolean         Podarilo se uzivatele vytvorit
     * addNewUser($_POST["jmeno"], $_POST["login"], $_POST["heslo"], $_POST["email"], $_POST["pravo"],$_POST["telefon"],$_POST["psc"],$_POST["ulice"]);
     */
    public function addNewUser($jmeno,$login, $heslo, $mail, $idPrava){
        $pole = array("login" =>$login,"jmeno" =>$jmeno,"heslo" =>$heslo,"mail" =>$mail,"idPrava" =>$idPrava);
        $q = "INSERT INTO uzivatel(login,jmeno,heslo,mail,ROLE)
                VALUES ('$pole[login]','$pole[jmeno]','$pole[heslo]','$pole[mail]','$pole[idPrava]')";
        $res = $this->executeQuery($q);
        if($res == null){
            return false;
        } else {
            return true;
        }
    }

    /**
     *  Upravi informace o danem uzivateli.
     *  ... vse potrebne ...
     *  @return boolean         Podarilo se data upravit?
     *  updateUserInfo($_SESSION["user"]["id_UZIVATEL"], $_POST["jmeno"], $heslo, $_POST["email"], $_POST["pravo"],$_POST["telefon"],$_POST["psc"],$_POST["ulice"]);
     */
    public function updateUserInfo($userId, $jmeno, $heslo, $mail, $idPrava){
        $pole = array("userId" =>$userId,"jmeno" =>$jmeno,"heslo" =>$heslo,"mail" =>$mail,"idPrava" =>$idPrava);
        $q = "UPDATE uzivatel
                SET jmeno='$pole[jmeno]', heslo='$pole[heslo]', mail='$pole[mail]', ROLE='$pole[idPrava]'
                WHERE id_UZIVATEL=$pole[userId]";
        $res = $this->executeQuery($q);
        if($res == null){
            return false;
        } else {
            return true;
        }
    }


    /**
     *  Upravi prava daneho uzivatele.
     *  ... vse potrebne ...
     *  @return boolean         Podarilo se data upravit?
     *  updateUserInfo($_SESSION["user"]["id_UZIVATEL"], $_POST["jmeno"], $heslo, $_POST["email"], $_POST["pravo"],$_POST["telefon"],$_POST["psc"],$_POST["ulice"]);
     */
    public function updateUserRights($userId, $idPrava){
        $pole = array("userId" =>$userId,"idPrava" =>$idPrava);
        $q = "UPDATE uzivatel
                SET ROLE='$pole[idPrava]'
                WHERE id_UZIVATEL=$pole[userId]";
        $res = $this->executeQuery($q);
        if($res == null){
            return false;
        } else {
            return true;
        }
    }

    /**
     *  Smaze daneho uzivatele z databaze.
     *  @param integer $userId  ID uzivatele.
     *  @return boolean         Podarilo se?
     */
    public function deleteUser($userId){
        $pole = array("userId" =>$userId);
        $q = "DELETE FROM uzivatel
                WHERE id_UZIVATEL=$pole[userId]";
        $res = $this->executeQuery($q);
        if($res == null){
            return false;
        } else {
            return true;
        }
    }
/////////////////////////uzivatele konec/////////////////////////////////
///////////////////////////////recenzich start///////////////////////////////////////////
///

    /**
     *  Vraci vsechny informace o recenzich.
     *  @return array      review     Pole s informacemi o konkretnim uzivateli nebo null.
     */
    public function allReviewInfo(){

        $q = "SELECT * FROM recenze";

        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        //print_r($res);
        if($res != null && count($res)>0){
            // vracim vse
            return $res;
        } else {
            return null;
        }
    }

    /**
     *  Vraci vsechny SUMy hodnoceni jednoho članku.
     *  @return array      review     Pole s informacemi o konkretnim uzivateli nebo null.
     */
    public function sumReviewInfo($id_prispevek){
        $pole = array("id_PRISPEVEK" =>$id_prispevek);
        $q = "SELECT SUM(gramatika) AS gramatika,
                     SUM(srozumitelnost) AS srozumitelnost,
                     SUM(narocnost) AS narocnost FROM recenze WHERE id_PRISPEVEK=$pole[id_PRISPEVEK]";

        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        //print_r($res);
        if($res != null && count($res)>0){
            // vracim vse
            return $res;
        } else {
            return null;
        }
    }

    /**
     *  Vraci počet recenzi hodnoceni jednoho članku.
     *  @return array      review     Pole s informacemi o konkretnim uzivateli nebo null.
     */
    public function coutReviewInfo($id_prispevek){
        $pole = array("id_pri" =>$id_prispevek);
        $q = "SELECT  COUNT(*) AS pocet FROM recenze WHERE id_PRISPEVEK=$pole[id_pri]";

        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        //print_r($res);
        if($res != null && count($res)>0){
            // vracim vse
            return $res;
        } else {
            return null;
        }
    }
    /**
     *  Vraci vsechny informace o recenzich PRODANEHO RECENZENTA.
     *  @return array      review     Pole s informacemi o konkretnim uzivateli nebo null.
     */
    public function allReviewInfoById($id_uzivatel){
        $pole = array("id_uzivatel" =>$id_uzivatel);
        $q = "SELECT * FROM recenze WHERE id_RECENZENT = $pole[id_uzivatel]";
        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        //print_r($res);
        if($res != null && count($res)>0){
            // vracim vse
            return $res;
        } else {
            return null;
        }
    }

    /**
     *  Recenzování prispevku
     *  ... vse potrebne ...
     *  @return boolean         Podarilo se data upravit?
     *
     */
    public function updateReview($gramatika, $srozumitelnost,$narocnost,$id_RECENZENT,$id_PRISPEVEK){
        $pole = array("gramatika" => $gramatika,"srozumitelnost"=>$srozumitelnost,"narocnost"=>$narocnost,"id_RECENZENT"=>$id_RECENZENT,"id_PRISPEVEK"=>$id_PRISPEVEK);
        $q = "UPDATE recenze
                SET gramatika='$pole[gramatika]',srozumitelnost='$pole[srozumitelnost]',narocnost='$pole[narocnost]'
                WHERE id_RECENZENT=$pole[id_RECENZENT] AND id_PRISPEVEK=$pole[id_PRISPEVEK]";
        $res = $this->executeQuery($q);
        if($res == null){
            return false;
        } else {
            return true;
        }
    }

    /**
     *  Vytvori v databazi noveho přiřazení k recenzování
     *  @return boolean         Podarilo se uzivatele vytvorit
     *
     */
    public function addNewReview($id_RECENZENT,$id_PRISPEVEK){
        $pole = array("id_RECENZENT"=>$id_RECENZENT,"id_PRISPEVEK"=>$id_PRISPEVEK);
        $q = "INSERT INTO `recenze` (`gramatika`,`srozumitelnost`,`narocnost`,`id_PRISPEVEK`,`id_RECENZENT`) VALUES (NULL, NULL, NULL,'$pole[id_PRISPEVEK]','$pole[id_RECENZENT]')";

        $res = $this->executeQuery($q);
        if($res == null){
            return false;
        } else {
            return true;
        }
    }
    /**
     *  existuje recenze.
     *  @return array      review     Pole s informacemi o konkretnim uzivateli nebo null.
     */
    public function existReview($id_RECENZENT,$id_PRISPEVEK){
        $pole = array("id_RECENZENT"=>$id_RECENZENT,"id_PRISPEVEK"=>$id_PRISPEVEK);
        $q = "SELECT * FROM recenze WHERE id_RECENZENT = $pole[id_RECENZENT] AND  id_PRISPEVEK = $pole[id_PRISPEVEK]";
        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        //print_r($res);
        if($res != null && count($res)>0){
            // vracim vse
            return $res;
        } else {
            return null;
        }
    }


    ////////////////////// recenze  konec////////////////////////
    //////////////////////prispevek zacatek////////////////////////
    /**
     *  Vytvori v databazi novy prispevek.
     *
     *  @return boolean         Podarilo se polozku vytvorit
     */
    public function addNewContribution($nazev, $pdf, $abstrakt,$autor){
        $pole = array("nazev" =>$nazev,"pdf"=>$pdf,"abstrakt"=>$abstrakt,"autor"=>$autor);

        $q = "INSERT INTO `prispevek` ( `nazev`, `platnost`, `pdf`, `abstrakt`, `id_AUTOR`) 
                VALUES ('$pole[nazev]',0,'$pole[pdf]','$pole[abstrakt]','$pole[autor]')";
        $res = $this->executeQuery($q);
        if($res == null){
            return false;
        } else {
            return true;
        }
    }

    /**
     *  Upravi informace o dane galerie.
     *  ... vse potrebne ...
     *  @return boolean         Podarilo se data upravit?
     */
    public function updateContributionInfo($nazev, $pdf, $abstrakt,$id_prispevek,$paltnost){
        $pole = array("nazev" =>$nazev,"pdf"=>$pdf,"abstrakt"=>$abstrakt,"id_prispevek"=>$id_prispevek,"paltnost"=>$paltnost);
        $q = "UPDATE prispevek
                SET nazev='$pole[nazev]',pdf='$pole[pdf]',abstrakt='$pole[abstrakt]',platnost='$pole[paltnost]'
                WHERE id_PRISPEVEK=$pole[id_prispevek]";

        $res = $this->executeQuery($q);
        if($res == null){
            return false;
        } else {
            return true;
        }
    }


    /**
     *  Vraci vsechny prispevky.
     *  @return array   Dostupna prava uzivatelu.
     */
    public function allContribution(){
        $q = "SELECT * FROM prispevek ;";
        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        return array_reverse($res); // pole otocim
    }
    /**
     *  Vraci prispevek s id.
     *  @return array   Dostupna prava uzivatelu.
     */
    public function ContributionByIdContribution($id_prispevek){
        $q = "SELECT * FROM prispevek WHERE id_PRISPEVEK = $id_prispevek;";
        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        return array_reverse($res); // pole otocim
    }


    /**
     *  Vraci vsechny  prispevky přihlášeného.
     *  @return array   Dostupna prava uzivatelu.
     */
    public function allContributionByIdUser(){
        $idUser = $_SESSION['user']['id_UZIVATEL'] +0;
        $q = "SELECT * FROM prispevek WHERE id_AUTOR = $idUser;";
        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        return array_reverse($res); // pole otocim
    }



    /**
     *  Vraci vsechny prispevek.
     *  @return array   Dostupna prava uzivatelu.
     */
    public function allContributionValidity(){
        $q = "SELECT * FROM prispevek WHERE platnost = 1;";
        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        return array_reverse($res); // pole otocim
    }
    /**
     *  Vraci id_galerie z galerii kde je fotka.
     *  @return array   Dostupna prava uzivatelu.
     */
    public function allContributionWithFoto(){
        $q = "SELECT  DISTINCT UMISTENI_id_GALERIE FROM fotka;";
        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        return array_reverse($res); // pole otocim
    }
    /**
     *  Vraci galerii s id_GALERIE.
     *  @return array   Dostupna prava uzivatelu.
     */
    public function selectionGalerieById($id_galerie){
        $pole = array("id_galerie" =>$id_galerie);
        $q = "SELECT * FROM galerie
            WHERE id_GALERIE=$pole[id_galerie]";
        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        return array_reverse($res); // pole otocim
    }


    //////////////////////galerie konec////////////////////////



    //////////////////////fotky ////////////////////////

    /**
     *  Vraci fotky s id_GALERIE.
     *  @return array   Dostupna prava uzivatelu.
     */
    public function selectionFotkyByIdGalerie($id_galerie){
        $pole = array("id_galerie" =>$id_galerie);
        $q = "SELECT * FROM fotka
            WHERE UMISTENI_id_GALERIE= $pole[id_galerie]
            AND platnost = 1";
        $res = $this->executeQuery($q);
        $res = $this->resultObjectToArray($res);
        return array_reverse($res); // pole otocim
    }

    //////////////////////fotky konec////////////////////////
}

?>