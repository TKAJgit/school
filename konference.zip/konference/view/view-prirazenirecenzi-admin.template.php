<?php
//// Sablona pro zobrazeni uvodu

// urceni globalnich promennych, se kterymi sablona pracuje
global $title, $recenze, $hlaseni,$zapsatRecenze;

// sablona je samostatna a provadi primy vypis do vystupu
// -> lze testovat bez zbytku aplikace
// -> pri vyuziti Twigu se sablona obejde bez PHP

?>
<html>
<head>
    <?php include('view-head.php'); ?>
</head>
<body>
<?php include($rozcestnikl);?>


<div id="tour" class="bg-1">
    <div class="container">
        <h1><?php echo $title; ?></h1>
        <?php echo $hlaseni; ?>
        <p>Před zapsání recenzí si prosím přečtěte tuto instruktáž.</p>
        <p>Každý příspěvek se hodnotí podle 3 krytérii gramatika, srozumitelnost a náročnost (potřebné znalostí). Kritéria se hodnotí od  1 do 5 jeko ve škole.</p>
        <p>Při zveřejnění článku je průměr z každého hodnovení viděd na titulní veřejné spránce.</p>
        <div class="col-lg-12  col-sm-12">
            <table frame="hsides" class="table table-hover">
               <tr class="info"><th>ID recenzenta</th><th>ID prispevku</th><th>gramatika</th><th>srozumitelnost</th><th>náročnost</th><th>Akce</th></tr>

                <?php

                echo"$zapsatRecenze";
                    foreach( $recenze as  $rec){

                        echo"
                            <tr>
                   
                                  <form action='' method='POST' >
                              
                                    <td>$rec[id_RECENZENT]</td>
                                    <td>$rec[id_PRISPEVEK]</td> 
                                    <td><input type='range' id='a' name='gramatika' value='$rec[gramatika]' min='1' max='5' oninput='x.value=parseInt(a.value);'><output name='x' for='a'>$rec[gramatika]</output></td>
                                    <td><input type='range' id='a' name='srozumitelnost' value='$rec[srozumitelnost]' min='1' max='5' oninput='x.value=parseInt(a.value);'><output name='x' for='a'>$rec[srozumitelnost]</output></td>
                                     <td><input type='range' id='a' name='narocnost' value='$rec[narocnost]' min='1' max='5' oninput='x.value=parseInt(a.value);'><output name='x' for='a'>$rec[narocnost]</output></td>
                             
                                                  <input type='hidden' name='recenzent' value='$rec[id_RECENZENT]'>
                                                  <input type='hidden' name='prispevek' value='$rec[id_PRISPEVEK]'>
                                     <td>
                                        <input type='submit'  class='btn btn-info' name='recenze' value='recenze'>                             
                                     </td>
                                  </form>
                            </tr>";
                    }

                echo"
               
            </table>
        </div>

   
        </div>

    </div>
</div>";
                 ?>
<?php include('view-footer.php');?>
</body>
</html>