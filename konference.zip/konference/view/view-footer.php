<?php
// spranka obsahuje zápatí které je vloženo do každé stránky
echo "
<footer class='container-fluid text-center'>
  <a href='' title='To Top'>
    <span class='glyphicon glyphicon-chevron-up'></span>
  </a>
  
  <span>
   <p> <a href='con-index.php?web=login'>LOGIN</a> | <a href='con-index.php?web=registrace'>REGISTRACE</a> | web builder<a href='' title='web builder'> Pavel Tkaj Tomiczek</a></p> </span>

</footer>
";
?>