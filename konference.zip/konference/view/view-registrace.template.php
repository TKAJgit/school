<?php
//// Sablona pro zobrazeni uvodu

// urceni globalnich promennych, se kterymi sablona pracuje
global $title,$hlaseni, $createSelectBox,$rozcestnikl;

// sablona je samostatna a provadi primy vypis do vystupu
// -> lze testovat bez zbytku aplikace
// -> pri vyuziti Twigu se sablona obejde bez PHP

?>
<html>
<head>



    <?php include('view-head.php'); ?>
</head>
<body>

<?php include($rozcestnikl);?>

<div id="tour" class="bg-1">
    <div class="container">
        <h1><?php echo $title;

        ?></h1>
        <div class="container-fluid" >
            <?php echo $hlaseni; ?>
            <form class="form-group" action="con-index.php?web=registrace" method="POST" oninput="x.value=(pas1.value==pas2.value)?'OK':'Nestejná hesla'">
                <table class="table table-hover">
                    <tr><td>Login:</td><td><input type="text" name="login" value="login" required></td></tr>
                    <tr><td>Heslo 1:</td><td><input type="password" name="heslo" id="pas1" required></td></tr>
                    <tr><td>Heslo 2:</td><td><input type="password" name="heslo2" id="pas2" required></td></tr>
                    <tr><td>Ověření hesla:</td><td><output name="x" for="pas1 pas2"></output></td></tr>
                    <tr><td>Jméno:</td><td><input type="text" name="jmeno" value="jmeno" required></td></tr>
                    <tr><td>E-mail:</td><td><input type="email" name="email" value="email" required></td></tr>
                    <tr><td>Právo:</td>
                        <input type='hidden' name='idNakup' value='$subnakupyUser[id_NAKUP]'>
                        <td></td>
                        <?php echo $createSelectBox; ?>
                    </tr>

                </table>

                <input type="submit" name="potvrzeni" class="btn btn-success" value="Registrovat">


            </form>
        </div>
    </div>
</div>


<?php include('view-footer.php');?>


</body>
</html>