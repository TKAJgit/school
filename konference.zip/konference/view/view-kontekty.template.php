<?php
//// Sablona pro zobrazeni uvodu

// urceni globalnich promennych, se kterymi sablona pracuje
global $title, $createSelectBox, $hlaseni;

// sablona je samostatna a provadi primy vypis do vystupu
// -> lze testovat bez zbytku aplikace
// -> pri vyuziti Twigu se sablona obejde bez PHP

?>
<html>
<head>
    <?php include('view-head.php'); ?>





</head>
<body>
<div id="tour" class="bg-1">
    <div class="container">
        <h1><?php echo $title; ?></h1>
        <?php echo $hlaseni; ?>
        <?php include($rozcestnikl);?>
        <h3>Pavel Tkaj Tomiczek</h3>
        <ul>
            <li>  Můžeš se se mnou spojit přes mail: tomiczek15(a)gmail.com</li>
            <li>  nebo přímo na telefon: 724 762 198.</li>
        </ul>
       <br>






    </div>
</div>
<?php include('view-footer.php');


?>
</body>
</html>

