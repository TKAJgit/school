<?php
//// Sablona pro zobrazeni uvodu

// urceni globalnich promennych, se kterymi sablona pracuje
global $title, $createSelectBox, $hlaseni;

// sablona je samostatna a provadi primy vypis do vystupu
// -> lze testovat bez zbytku aplikace
// -> pri vyuziti Twigu se sablona obejde bez PHP

?>
<html>
<head>
<?php include('view-head.php'); ?>





</head>
<body>
<div id="tour" class="bg-1">
    <div class="container">
        <h1><?php echo $title; ?></h1>
        <?php echo $hlaseni; ?>
        <?php include($rozcestnikl); ?>

        <form action="con-index.php?web=nastaveni" method="POST" oninput="x.value=(pas1.value==pas2.value)?'OK':'Nestejná hesla'">
            <table class="table table-hover">
                <tr><td>Současné heslo:</td><td><input type="password" name="heslo-puvodni" required></td></tr>
                <tr><td>Login:</td><td><?php echo $_SESSION["user"]["login"]; ?></td></tr>
                <tr><td>Heslo 1:</td><td><input type="password" name="heslo" id="pas1"></td></tr>
                <tr><td>Heslo 2:</td><td><input type="password" name="heslo2" id="pas2"></td></tr>
                <tr><td>Ověření hesla:</td><td><output name="x" for="pas1 pas2"></output></td></tr>
                <tr><td>Jméno:</td><td><input type="text" name="jmeno" value="<?php echo $_SESSION["user"]["jmeno"]; ?>" required></td></tr>
                <tr><td>E-mail:</td><td><input type="email" name="email" value="<?php echo $_SESSION["user"]["mail"]; ?>" required></td></tr>
                <tr><td>Právo:</td>
                    <td><?php echo $createSelectBox; ?></td>
                </tr>

            </table>

            <input type="submit" name="potvrzeni" class="btn btn-info" value="Upravit osobní údaje">
        </form>
    </div>
</div>
<?php include('view-footer.php');?>
</body>
</html>