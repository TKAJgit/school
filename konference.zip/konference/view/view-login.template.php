<?php
//// Sablona pro zobrazeni uvodu

// urceni globalnich promennych, se kterymi sablona pracuje
global $title,$logInOutView,  $hlaseni;

// sablona je samostatna a provadi primy vypis do vystupu
// -> lze testovat bez zbytku aplikace
// -> pri vyuziti Twigu se sablona obejde bez PHP

?>

<html>
    <head>
         <?php include('view-head.php');?>
    </head>
    <body>
    <?php include($rozcestnikl);?>


        <div id="tour" class="bg-1">
            <div class="container">
                <h1> <?php echo $title;

                    echo $hlaseni; ?></h1>
                  <?php echo $logInOutView;?>
            </div>
        </div>

    <?php include('view-footer.php');?>
    </body>
</html>