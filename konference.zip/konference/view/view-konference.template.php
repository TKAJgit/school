<?php
//// Sablona pro zobrazeni uvodu

    // urceni globalnich promennych, se kterymi sablona pracuje
    global $title, $prispevek,$hlaseni,$hodnoceni, $upozorneni;

    // sablona je samostatna a provadi primy vypis do vystupu
    // -> lze testovat bez zbytku aplikace
    // -> pri vyuziti Twigu se sablona obejde bez PHP

?>
<html>
<head>


    <?php include('view-head.php');?>


</head>
<body>
<?php include($rozcestnikl);

?>


<div class="container-fluid bg-1 text-center titletkaj">
    <div class="row margtopbot25">

        <div class="col-sx-12">
            <h1 class="whitetext">Koference</h1>
            <p class="whitetext">Staň se členem, prezentuj články a dostaň se až na post recenzenta</p>

        </div>

    </div>
</div>

<?php echo $hlaseni; ?>
<div class="container-fluid bg-6 text-center fototkaj">
    <h3>Validované články</h3>
    <p>Články zde zobrazené byli předem přečteny a ohodnoceny Recenzenty  a následně<br>
        po zvázění správcem stránek, byl článek umístěn sem titulní stranu k nahlédnutí.</p>
<div class='container-fluid galerietkaj' >


<?php  foreach ($prispevek as $i => $pris){
           echo"
<div class='col-sm-6 col-md-4'>
           

        
            
 <div class='panel panel-default margtop20'>
  <div class='panel-heading'>
  
       <h3>".$pris['nazev']." </h3>
       <div class = >narocnost:<span class='badge'>".$hodnoceni[$pris['id_PRISPEVEK']][0]['narocnost']."</span>
             srozumitelnost: <span class='badge'>".$hodnoceni[$pris['id_PRISPEVEK']][0]['srozumitelnost']."</span>
              gramatika: <span class='badge'>".$hodnoceni[$pris['id_PRISPEVEK']][0]['gramatika']."</span>
       </div>
  </div>          
  <div class='panel-body'>
  <div>Abstrakt: ".$pris['abstrakt']."</div>
        <form action='' method='POST' >
            <input type='hidden' name='foto' value=".$pris['pdf'].">
            <input type='submit' name='Download' class='btn' value='Download: ".$pris['pdf']."'>
        </form>
   </div>
</div>

            
</div>";
        }
?>
</div>

</div>


<?php

include('view-footer.php');?>

</body>
</html>