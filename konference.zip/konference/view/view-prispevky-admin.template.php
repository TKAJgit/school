<?php
//// Sablona pro zobrazeni administrace fotek

// urceni globalnich promennych, se kterymi sablona pracuje
global $title,$hlaseni,$prispevky,$platnost,  $upozorneni ;

// sablona je samostatna a provadi primy vypis do vystupu

?>
<html>
<head>
      <?php include('view-head.php');?>

</head>
<body>

        <?php include($rozcestnikl);?>
<div id="tour" class="bg-1">
    <div class="container">


        <h1> <?php echo $title;

        ?></h1>
        <?php echo $hlaseni; ?>
        <p>stav článku: Pokud je článek přijat tak je u něj 1. Pokud přijat ještě není tak je ohodnocen 0 a pokud je u něj 2 tak byl zamítnut.</p>
        <table frame="hsides" class="table table-hover">
            <tr class="info"><th>ID</th><th>nazev</th><th>pdf</th><th>abstrakt</th><th>stav článku</th><th>autor</th><th>akce</th></tr>

            <?php

            echo"<form action='' method='POST' enctype='multipart/form-data'>
                    <tr>
                        <td>+</td>
                        <td><input type='text'  name='nazev' size='10' value='nazev'></td>
                         <td><input type='file' name='file' size='10'></td>
                         <td><input type='text'  name='abstrakt' size='30' value='abstrakt'></td>
                         <td></td>
                        <td></td>
                        <td><input type='submit' class='btn btn-success' name='zapsat' value='zapsat'></td>
                    </tr>";


            foreach ($prispevky as $prispevek){
                echo "
                    <form action='' method='POST' >
                    <tr>
                        <td>$prispevek[id_PRISPEVEK]</td>
                        <td><input type='text'  name='nazev' size='10' value=$prispevek[nazev]></td>
                        <td>$prispevek[pdf]</td>
                        <input type='hidden' name='pdf' value='$prispevek[pdf]'>
                        <td><input type='text'  name='abstrakt' size='30' value=$prispevek[abstrakt]></td>
                         <td>".$platnost[$prispevek['id_PRISPEVEK']]."</td>
                        
                        <td>$prispevek[id_AUTOR]</td>
                        <input type='hidden' name='id_prispevek' value='$prispevek[id_PRISPEVEK]'>
                        
                        <td><input type='submit' class='btn btn-success' name='upravit' value='upravit'></td>
                      
                    </tr>

            </form>
                
                
                ";
            }  ?>





        </table>
</div>
</div>

        <?php


        include('view-footer.php');?>
</body>
</html>