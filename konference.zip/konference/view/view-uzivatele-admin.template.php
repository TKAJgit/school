<?php
//// Sablona pro zobrazeni uvodu

// urceni globalnich promennych, se kterymi sablona pracuje
global $title, $users,$hlaseni,$rozcestnikl,$createSelectBox;

// sablona je samostatna a provadi primy vypis do vystupu
// -> lze testovat bez zbytku aplikace
// -> pri vyuziti Twigu se sablona obejde bez PHP

?>

<html>
<head>
<?php include('view-head.php'); ?>

</head>
<body>
<div id="tour" class="bg-1">
    <div class="container">
        <h1> <?php echo $title; ?></h1>

        <?php include($rozcestnikl);
         echo $hlaseni; ?>

        <b>Seznam uživatelů</b>
        <table frame="hsides" class="table table-hover">
            <tr class="info"><th>ID</th><th>Login</th><th>Jméno</th><th>E-mail</th><th>Právo</th><th>Akce</th></tr>
            <?php
            // vsichni uzivatele
            foreach($users as $u){
                if($u["id_UZIVATEL"]!=$_SESSION["user"]["id_UZIVATEL"]){ // aktualni uzivatele nevypisuju
                    echo "<tr><td>$u[id_UZIVATEL]</td><td>$u[login]</td><td>$u[jmeno]</td><td>$u[mail]</td>
                                        <form action='con-index.php?web=uzivateleAdmin' method='POST'>
                                        <td>
                                        $u[nazev]
                                         
                                        </td>
                                        <td>
                                            
                                                <input type='hidden' name='user-id' value='$u[id_UZIVATEL]'>
                                                 
                                                <input type='submit' class='btn btn-info' name='upravit' value='Upravit'>  
                                                 $createSelectBox
                                           
                                        </td>
                                          <td><input type='submit' class='btn btn-danger' name='smazat' value='smazat'></td>
                                         </form>
                                      </tr>";
                }
            }
            ?>
        </table>
    </div>
</div>
<?php include('view-footer.php');?>
</body>
</html>