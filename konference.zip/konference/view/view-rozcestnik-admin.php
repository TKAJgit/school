
<?php

echo "
<nav class='navbar navbar-default navbar-fixed-top menu textmenu'>
  <div class='container-fluid'>
    <div class='navbar-header'>
      <button type='button' class='navbar-toggle' data-toggle='collapse' data-target='#myNavbar'>
        <span class='icon-bar'></span>
        <span class='icon-bar'></span>
        <span class='icon-bar'></span>                        
      </button>
      <a class='navbar-brand' href='con-index.php?web=uvod'> 
          <p>
             <img src='image/tkajatr02.jpg' alt='logo' class='logofoto'>  Konference
          </p>
      </a>
    </div>
    <div class='collapse navbar-collapse' id='myNavbar'>
      <ul class='nav navbar-nav navbar-right'>
        <li><a href='con-index.php?web=uvod'>Úvodni strana</a></li>
        <li><a href='con-index.php?web=kontakty'>Kontakt</a></li>

        <li><a href='con-index.php?web=uzivateleAdmin'><p class='textmenuadm'>Uživatele Admin</p></a></li>  
           
         <li><a href='con-index.php?web=priRecAdmin'><p class='textmenuadm'>Přiřazení recenzí</p></a></li>     
 
     <li ><a href='con-index.php?web=nastaveni' ><p class='textmenuadm'>Nastaveni Uživatele</p></a></li>     
     <li><a href='con-index.php?web=prispevkyAdmin'><p class='textmenuadm'>Příspěvky Admin</p></a></li>     
  

      </ul>
    </div>
  </div>
</nav>
";
?>